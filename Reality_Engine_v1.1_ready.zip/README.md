# Reality Engine

Reality Engine v1.1
Created by Mr. Hudson | ArtHaus Systems 2025
Carpe Constructum — Seize the Construct.

Quick start:
```
pip install streamlit numpy matplotlib pillow
streamlit run streamlit_app.py
```
